import './component/app-bar.js';
import './component/note-form.js';
import './component/note-item.js';
import './component/footer-bar.js';
import './data/notes.js';